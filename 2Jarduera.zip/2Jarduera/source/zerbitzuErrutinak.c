/*-------------------------------------
zerbitzuErrutiank.c
-------------------------------------*/

#include <nds.h>
#include <stdio.h>
#include "definizioak.h"
#include "periferikoak.h"

int EGOERA=HASTEKO;

void tekEten ()
{
	if (EGOERA==HASTEKO)
	{	
		if (SakatutakoTekla()==A)
		{
			EGOERA=KONTATZEN;
			ErlojuaMartxanJarri();
			//iprintf("\x1b[13;5HPasa diren segunduak=0");
		}
		else iprintf("\x1b[17:5H Tekla: %d",SakatutakoTekla());
	}
}

void tenpEten()
{
	static int tik=0;
	static int seg=0;

	if (EGOERA==KONTATZEN)
	{
		tik++;
		if (tik==5)
		{
			seg ++;
			iprintf("\x1b[13;5HPasa diren segunduak=%d", seg);
			tik=0;
		}
	}
}

void etenZerbErrutEzarri()
{
			// HEMEN IDATZI BEHAR DUZUE ZUEN KODEA
	
}


