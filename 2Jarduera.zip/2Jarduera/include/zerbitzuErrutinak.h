/*-------------------------------------
zerbitzuErrutinak.h
-------------------------------------*/

extern void tekEten ();
extern void tenpEten();
extern void etenZerbErrutEzarri();
