/* Bideo sistemaren definizioa */
extern void hasieratuBideoa();
extern void GrafikoakHasieratu();



