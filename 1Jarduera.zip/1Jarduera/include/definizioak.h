/*-------------------------------------
definizioak.h
-------------------------------------*/

#include <nds.h>		//nds-rako garatuta dagoen liburutegia
#include <stdio.h>		//c-ko liburutegi estandarra sarrera eta irteerako funtzioak definitzen dituena
#include <stdlib.h>		//c-ko liburutegi estandarra memoria erreserbak eta zenbaki konbertsioak egiteko
#include <unistd.h>		//Sistema eragileen arteko konpatibilitatea ziurtatzeko liburutegia

//teklatuaren erregistroak
#define TEKLAK_DAT	(*(vu16*)0x4000130) //teklatuaren datu erregistroa
#define TEKLAK_KNT	(*(vu16*)0x4000132) //teklatuaren kontrol erregistroa

//denboragailuaren (Timer0) erregistroak
#define DENB0_KNT   (*(vuint16*)0x04000102) //kontrol erregistroa
#define DENB0_DAT    (*(vuint16*)0x04000100) //datu-erregistroa

//ukimen-pantailaren erregistroak
touchPosition PANT_DAT;

// Teklei izena eman diegu zenbakiak nahasgarriak izan daitezkeelako

#define A				0 
#define B				1
#define SELECT			2 
#define START			3
#define ESKUBI			4 
#define EZKER			5
#define GORA			6 
#define BEHERA			7
#define R				8 
#define L				9


