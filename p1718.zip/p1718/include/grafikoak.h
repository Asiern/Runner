/* Bideo sistemaren definizioa */
extern void hasieratuBideoa();
extern void GrafikoakHasieratu();
extern void hasieratuFondoak();


/* Spriteen memoria hasieratu */
extern void initSpriteMem();

extern void HasieratuGrafikoakSpriteak();
