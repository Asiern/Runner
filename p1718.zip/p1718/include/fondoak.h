/*-------------------------------------
fondoak.h
-------------------------------------*/

extern void erakutsiAtea();
extern void erakutsiAteaIrekita();
